global.$ = global.jQuery = require('jquery');

require('bootstrap/dist/js/bootstrap');
