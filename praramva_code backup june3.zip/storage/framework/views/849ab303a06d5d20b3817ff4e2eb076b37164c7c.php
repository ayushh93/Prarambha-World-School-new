<style>
    @media (min-width: 1200px) {
        .container {
            max-width: 1220px;
        }
    }

    body {
        font-family: Helvetica Neue, sans-serif;
        color: #000;
        overflow-x: hidden;
    }

    a {
        text-decoration: none !important;
    }
    input:focus{
        outline: none;
    }
    .back-to-top {
        position: fixed;
        bottom: 30px;
        right: 30px;
        background: #282471;
        z-index: 1;
        color: white;
    }

    .back-to-top:hover {
        color: #D98E05;
    }

    /*header starts*/

    header {
        background: #f3f3f3;
    }

    #header {
        position: relative;
        box-shadow: 0 0 6px #00000029;
    }

    #navmenu {
        position: relative;
        padding: 10px 0 0;
    }

    #siteLogo {
        position: absolute;
        top: 0;
        left: 0;
        z-index: 2;
    }

    .logo-img {
        width: 160px;
        height: auto;
        background: white;
        padding: 15px 1px;
        border-radius: 0px 0px 25px 25px;
        box-shadow: 0 0 5px #00000030;
    }

    .top-contact {
        padding-right: 16px;
    }

    .top-contact,
    .top-contact a {
        font-size: 14px;
        color: #605F5F;
    }

    .top-contact a:hover {
        color: #D98E05;
    }

    .top-location:hover,
    .top-call:hover {
        color: #D98E05;
        cursor: default;
    }

    .top-contact .fa {
        background: white;
        padding: 5px;
        border-radius: 7px;
        margin-right: 5px;
    }

    .top-contact .fab {
        background: white;
        padding: 8px 10px;
        border-radius: 50%;
        margin: 5px;
        transition: all 1s ease;
    }

    .top-contact .fab:hover {
        transform: rotate(360deg);
    }

    .top-call {
        margin-bottom: 5px;
    }

    ul#menuBar {
        margin-bottom: 0;
    }

    #desktopNav li.nav-item {
        display: inline-block;
        margin: 0 3px 10px;
    }

    #desktopNav a.nav-link {
        color: #605F5F;
        position: relative;
        font-size: 15px;
        padding: 8px 16px;
    }

    a.nav-link:hover {
        color: #333;
    }

    a.nav-link.active {
        color: #333;
        font-weight: 600;
    }

    #desktopNav a.nav-link:before {
        position: absolute;
        -webkit-transition: all 0.35s ease;
        transition: all 0.35s ease;
    }

    #desktopNav a.nav-link:before {
        bottom: 0;
        display: block;
        height: 3px;
        left: 0;
        width: 0%;
        content: "";
        background-color: #D98E05;
    }

    #desktopNav a.nav-link:hover:before,
    #desktopNav a.nav-link.active:before {
        opacity: 1;
        width: 100%;
    }

    #desktopNav .dropdown-menu {
        z-index: 1000;
        padding: 20px;
        margin: 18px 0px;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid rgb(255, 255, 255);
        border-radius: 2px;
        -webkit-box-shadow: 0px 3px 11px 0px rgba(0, 0, 0, 0.09);
        -moz-box-shadow: 0px 3px 11px 0px rgba(0, 0, 0, 0.09);
        box-shadow: 0px 3px 11px 0px rgba(0, 0, 0, 0.09);
    }

    .dropdown-item {
        display: block;
        width: 100%;
        padding: 5px 10px;
        clear: both;
        font-weight: 400;
        color: #282471;
        text-align: inherit;
        white-space: nowrap;
        background-color: transparent;
        border: 0;
        font-size: 15px;
        line-height: 15px;
        font-weight: 600;
    }

    #desktopNav .dropdown .dropdown-menu {
        display: block;
        visibility: hidden;
        opacity: 0;
        -webkit-transform: translateY(20px);
        -ms-transform: translateY(20px);
        transform: translateY(20px);
        -webkit-transition: all .3s ease-in;
        -o-transition: all .3s ease-in;
        transition: all .3s ease-in
    }

    #desktopNav .dropdown:hover>.dropdown-menu {
        visibility: visible;
        opacity: 1;
        -webkit-transform: scaleY(1);
        -ms-transform: scaleY(1);
        transform: scaleY(1);
        opacity: 1;
        visibility: visible;
    }

    #desktopNav .dropdown-submenu {
        position: relative;
    }

    #desktopNav .dropdown-submenu .dropdown-menu {
        top: 0px;
        left: 100%;
        margin-left: 13px;
        margin-right: .1rem;
    }

    .mega-dropdown {
        position: unset;
    }

    .mega-dropdown-menu {
        width: 82%;
        margin-left: auto !important;
        top: 30px;
        right: 10px;
    }

    .mega-dropdown-menu ul {
        list-style-type: none;
    }

    .dropdown-item:focus,
    .dropdown-item:hover {
        color: #D98E05;
        text-decoration: none;
    }

    .menu-img-block {
        display: flex;
        justify-content: space-between;
        background: #f5f5f5;
        padding: 10px;
    }

    .menu-img-block img {
        width: 200px;
        height: 200px;
        object-fit: cover;
    }

    .left-block-link a {
        display: inline-block;
        background: #D98E05;
        padding: 10px 16px;
        color: white;
        margin: 8px 0;
    }

    .left-block-link a:hover {
        background: #b76d02;
    }

    .left-block-text {
        font-size: 30px;
        font-weight: 600;
        color: #282471;
        line-height: 30px;
    }

    .menu-img-block {
        padding: 20px;
    }

    .navbar {
        padding: 0;
    }

    #mobileNav a.nav-link {
        padding: 4px 10px;
        color: #333;
        font-size: 15px;
    }

    #mobileNav .dropdown-item {
        text-align: right;
        font-size: 15px;
        color: #333;
        font-weight: 300;
    }

    @media  only screen and (max-width: 992px) {
        #desktopNav {
            display: none;
        }
    }

    @media  only screen and (min-width: 992px) {
        #mobileNav {
            display: none;
        }
    }

    /*header ends*/

    /*footer starts*/

    .footer-top {
        background: #f3f3f3;
        padding: 40px 0;
        margin-top: 30px;
    }

    ul.footer-links {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    ul.footer-links li {
        margin-bottom: 5px;
    }

    ul.footer-links a {
        color: #555;
    }

    ul.footer-links a:hover {
        color: #D98E05;
    }

    .footer-social .fab {
        background: white;
        padding: 10px 13px;
        border-radius: 50%;
        color: #555555;
        margin-right: 5px;
        margin-bottom: 10px;
        transition: all 1s ease;
    }

    .footer-social .fab:hover {
        transform: rotate(360deg);
    }

    .footer-social .fab:hover {
        color: #D98E05;
    }

    .footer-location,
    .footer-phone,
    .footer-mail {
        margin-bottom: 5px;
    }

    .footer-location:hover,
    .footer-phone:hover,
    .footer-mail:hover {
        color: #D98E05;
        cursor: default;
    }

    .footer-contact .fa {
        color: #D98E05;
        width: 20px;
    }

    .footer-title {
        font-size: 24px;
        font-weight: 600;
        margin-bottom: 10px;
        text-transform: uppercase;
    }

    .quick-links {
        text-align: right;
    }

    .copyright {
        padding: 20px 0;
        color: #333333;
    }

    .copyright a {
        color: #333;
    }

    .copyright a:hover {
        color: #D98E05;
    }

    /*footer ends*/

    /*homepage CSS starts*/

    img.homeslider-img {
        height: 500px;
        object-fit: cover;
    }

    #homeSlider .owl-nav {
        position: absolute;
        width: 100%;
        top: 42%;
    }

    #homeSlider .fa {
        color: white;
        font-size: 24px;
        padding: 11px 16px;
        border: 2px solid white;
        border-radius: 50%;
    }

    #homeSliderSection .owl-theme .owl-nav [class*=owl-] {
        border-radius: 50%;
        outline: none;
    }

    #homeSliderSection .owl-theme .owl-nav [class*=owl-]:hover {
        background: #33333360;
    }

    #homeSlider .owl-prev {
        position: absolute;
        left: 50px;
    }

    #homeSlider .owl-next {
        position: absolute;
        right: 50px;
    }

    #homeSlider .item {
        position: relative;
    }

    #homeSlider .slider-caption {
        position: absolute;
        bottom: 10%;
        width: 100%;
        text-align: center;
        background: #D98E0565;
        color: white;
        font-size: 22px;
        font-weight: 600;
        padding: 10px 0;
        text-transform: uppercase;
    }

    .home-section {
        padding: 50px 0;
    }

    #since2000Section {
        background: #f3f3f3;
    }

    #since-block {
        position: relative;
        background-size: contain;
        background-repeat: no-repeat;
        background-position-x: -120px;
        height: 490px;
        padding-top: 60px;
        z-index: 0;
    }

    .gradient-overlay {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        background: linear-gradient(90deg, rgba(243, 243, 243, 0) 30%, rgba(243, 243, 243, 1) 47%);
        z-index: -1;
    }

    .since2000-block {
        padding: 40px 150px 60px 40px;
        background: #fff;
    }

    .since-title {
        font-size: 24px;
        font-weight: 600;
        line-height: 20px;
    }

    .title-bar {
        display: block;
        width: 180px;
        height: 3px;
        background: #555;
        margin: 15px 0;
    }

    .since-text {
        margin-bottom: 50px;
    }

    .learn-more-btn a {
        color: #555;
        border: 2px solid #555;
        padding: 16px 22px;
        text-transform: uppercase;
        font-weight: 600;
    }

    .learn-more-btn a:hover {
        color: #d98e05;
        border: 2px solid #d98e05;
    }

    .section-title {
        font-size: 30px;
        font-weight: 600;
        line-height: 30px;
    }

    .section-tagline {
        font-size: 17px;
        margin-bottom: 40px;
    }

    #principal-block {
        position: relative;
        background-size: contain;
        background-repeat: no-repeat;
        background-position-x: -120px;
        height: 500px;
        padding-top: 50px;
        z-index: 0;
    }

    .gradient-overlay2 {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        background: linear-gradient(90deg, rgba(255, 255, 255, 0) 30%, rgba(255, 255, 255, 1) 47%);
        z-index: -1;
    }

    .principal-message-block {
        padding: 40px 90px 60px 40px;
        background: #f5f5f5;
    }

    .news-title-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
    }

    .news-card-img {
        width: 100%;
        height: 320px;
        object-fit: cover;
    }

    .news-title,
    .announcement-title {
        font-size: 24px;
        color: #555;
        font-weight: 600;
    }

    .announcement-title-bar {
        width: 70px;
        height: 2px;
        background: #555;
        margin: 2px 0 20px;
    }

    .see-all a {
        color: #D98E05;
    }

    .see-all a:hover {
        text-decoration: underline !important;
    }

    .news-section {
        padding-right: 40px;
    }

    .news-block-text {
        padding: 20px 20px 30px;
        background: #F5F5F5;
    }

    .news-card-heading {
        font-size: 18px;
        text-transform: uppercase;
        font-weight: 600;
        margin-bottom: 8px;
    }

    .news-card-demo-text {
        font-size: 14px;
        margin-bottom: 20px;
    }

    .news-card-btn a {
        text-transform: uppercase;
        color: #555;
        border: 1px solid;
        padding: 12px 15px;
        font-size: 13px;
        font-weight: 600;
    }

    .news-card-btn a:hover {
        color: #D98E05;
        border: 1px solid #D98E05;
    }

    .single-news-img {
        width: 100%;
        height: 410px;
        object-fit: cover;
        margin-bottom: 20px;
    }

    .home-gallery-section {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-gap: 20px;
    }

    .gallery-img-wrap {
        width: 100%;
        height: 320px;
        overflow: hidden;
    }

    .gallery-img-wrap img {
        width: 100%;
        height: 320px;
        object-fit: cover;
        transition: all 0.5s ease;
    }

    .gallery-img-wrap:hover img {
        transform: scale(1.1);
    }

    img.partner-img {
        height: 160px;
        object-fit: contain;
    }

    .why-block {
        padding: 20px;
    }

    .why-block-icon {
        width: 110px;
        height: 110px;
        object-fit: contain;
        padding: 20px;
        background: #4C4C5012;
        border-radius: 50%;
        margin-bottom: 20px;
        transition: all 0.3s ease;
    }

    .why-block-icon:hover {
        transform: translateY(-5px);
    }

    .form-download h6,
    .apply-online h6 {
        color: #000;
        font-size: 20px;
        font-weight: 500;
    }

    /*homepage CSS ends*/

    #pageBanner {
        position: relative;
        height: 430px;
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }

    .banner-text {
        position: absolute;
        width: 100%;
        top: 45%;
        font-size: 30px;
        color: #fff;
        text-shadow: 0 3px 6px #00000029;
        text-align: center;
        z-index: 1;
    }

    .banner-overlay {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: #26242250;
    }

    #breadcrumb {
        background: #f3f3f3;
        padding: 8px 0;
        font-size: 14px;
    }

    .history-img {
        width: 100%;
        height: 500px;
        object-fit: cover;
        object-position: center;
    }

    .content-heading {
        font-size: 18px;
    }

    .content-heading-bar {
        width: 40px;
        height: 2px;
        background: #555;
        margin: 8px 0 20px;
    }

    .content-text {
        font-size: 14px;
        text-align: justify;
    }

    #about-section {
        padding: 50px 0;
    }

    .CBSE-img {
        width: 100%;
        object-fit: cover;
    }

    .whyrai-img {
        width: 100%;
        object-fit: cover;
        height: 500px;
    }

    #chairman-block {
        position: relative;
        background-size: contain;
        background-repeat: no-repeat;
        background-position-x: -120px;
        height: 520px;
        padding-top: 150px;
        z-index: 0;
    }

    .chairman-block-box {
        padding: 30px 30px 30px 70px;
        background: #f5f5f5;
        font-size: 32px;
    }

    .message-line {
        width: 180px;
        height: 2px;
        background: #555;
        margin: 10px 0;
    }

    .principal-block-box {
        padding: 30px 30px 30px 70px;
        background: #f5f5f5;
        font-size: 24px;
    }

    .profile-img {
        width: 100%;
        height: 350px;
        object-fit: cover;
    }

    .profile-block {
        position: relative;
        margin: 15px 10px;
    }

    .profile-detail {
        position: relative;
        width: 90%;
        padding: 15px 5px;
        text-align: center;
        background: #f3f3f3;
        margin-top: -18px;
        z-index: 1;
    }

    .section-heading {
        font-size: 20px;
    }

    #announcementSection,
    #newsSection {
        padding: 30px 0;
    }

    .news-card {
        margin-bottom: 20px;
        transition: all 0.3s ease-out;
    }

    .news-card:hover {
        box-shadow: 0 0 7px #00000050;
    }

    .news-banner-img {
        width: 100%;
        height: 420px;
        object-fit: cover;
        object-position: center;
    }

    #singleNewsBanner {
        margin-bottom: 40px;
    }

    .news-heading {
        font-size: 22px;
        font-weight: 600;
        margin-bottom: 10px;
    }

    .news-content {
        font-size: 15px;
        margin-bottom: 50px;
    }

    #beyondBanner {
        margin-bottom: 40px;
    }

    .beyond-img {
        width: 100%;
        height: 430px;
        object-fit: cover;
    }

    .singlepage-heading {
        font-size: 22px;
        font-weight: 600;
        margin-bottom: 10px;
    }

    .singlepage-content {
        font-size: 15px;
    }

    .singlepage-heading-bar {
        width: 80px;
        height: 2px;
        background: #555;
        margin-bottom: 20px;
    }

    a.download-btn {
        border: 1px solid #555;
        padding: 10px 20px;
    }

    .form-download,
    .form-download a {
        color: #fff;
    }

    #studentPage {
        padding: 40px 0;
    }

    .studentprofile-block {
        margin-bottom: 25px;
    }

    .studentprofile-img {
        width: 100%;
        height: 270px;
    }

    .studentprofile-detail {
        background: #f5f5f5;
        font-size: 15px;
        text-align: center;
        padding: 15px;
    }

    .studentprofile-name {
        font-weight: 600;
        font-size: 16px;
    }

    .academicbanner-img,
    .servicebanner-img {
        width: 100%;
        height: 450px;
        object-fit: cover;
    }

    #academicSection {
        padding: 50px 0;
    }

    .academic-img,
    .service-img {
        width: 100%;
        height: 530px;
        object-fit: cover;
    }

    .gallery-slider-img {
        height: 460px;
        object-fit: cover;
    }

    #gallerySlider .owl-dots {
        position: absolute;
        width: 100%;
        bottom: 10px;
    }

    #gallerySlider .owl-dot span {
        width: 13px;
        height: 13px;
        margin: 5px;
    }

    .gallery-slider-overlay {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: #26242230;
    }

    #gallerySection {
        padding: 50px 0;
    }

    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-gap: 20px;
    }

    .gallery-img {
        width: 100%;
        height: 260px;
        object-fit: cover;
        transition: all 0.5s ease;
    }

    .gallery-img:hover {
        transform: scale(1.02);
    }

    #html5-watermark {
        display: none !important;
    }

    .lightbox iframe {
        min-height: 390px;
    }

    #calenderSection {
        padding: 50px 0;
    }

    form#onlineAdmissionform {
        border: 1px solid #555;
        padding: 12px;
    }

    .admission-logo {
        width: 100%;
    }

    .admission-title {
        font-size: 32px;
        font-weight: 600;
        color: #10016F;
    }

    .alert {
        text-align: center;
        margin-bottom: 0;
    }

    #preview {
        width: 100px;
        height: 110px;
        margin-left: auto;
        margin-right: auto;
        padding: 5px;
        border: 2px solid #ddd;
        margin-bottom: 5px;
    }

    #img_container {
        border-radius: 5px;
        width: 100%;
    }

    .input-group {
        width: 100%;
    }

    .imgInp {
        width: 100%;
        background-color: #d3d3d3;
    }

    .loading {
        animation: blinkingText ease 2.5s infinite;
    }

    @keyframes  blinkingText {
        0% {
            color: #000;
        }

        50% {
            color: transparent;
        }

        99% {
            color: transparent;
        }

        100% {
            color: #000;
        }
    }

    .custom-file-label {
        cursor: pointer;
        overflow: hidden;
        white-space: nowrap;
        padding: 5px;
        font-size: 13px;
        height: auto;
        text-align: left;
    }

    .custom-file-label::after {
        padding: 5px 7px;
    }

    .online-form.text-center {
        padding: 10px;
        border: 2px solid #ccc;
    }

    .form-body {
        padding: 10px;
    }

    .form-div {
        text-align: left;
        margin-bottom: 10px;
    }

    #admissionForm input[type="text"],
    #admissionForm input[type="date"] {
        width: 100%;
        padding: 5px;
    }

    #admissionForm input[type="radio"] {
        margin: 5px;
    }

    .form-label {
        font-weight: 600;
    }

    .form-section-headline {
        font-size: 19px;
        font-weight: 600;
        text-align: left;
        padding-top: 8px;
        text-transform: uppercase;
    }

    .form-bar {
        width: 50px;
        height: 3px;
        background: #aaa;
        margin: 8px 0;
    }

    #admissionForm textarea {
        width: 100%;
        text-align: left;
        padding: 5px;
    }


    .back-to-top {

        background: rgb(6, 110, 37);
    }

    .back-to-top i {
        color: #fff;
    }
    /* Customize the label (the container) */
    .customcheck {
        position: relative;
        padding-left: 30px;
        margin: 5px 20px 10px 5px;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    /* Hide the browser's default checkbox */
    .customcheck input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
        height: 0;
        width: 0;
    }

    /* Create a custom checkbox */
    .checkmark {
        position: absolute;
        top: 0;
        left: 0;
        height: 20px;
        width: 20px;
        background-color: #fff;
    }

    /* On mouse-over, add a grey background color */
    .customcheck:hover input~.checkmark {
        background-color: #fff;
    }

    /* When the checkbox is checked, add a blue background */
    .customcheck input:checked~.checkmark {
        background-color: rgb(6, 110, 37);
    }

    /* Create the checkmark/indicator (hidden when not checked) */
    .checkmark:after {
        content: "";
        position: absolute;
        display: none;
    }

    /* Show the checkmark when checked */
    .customcheck input:checked~.checkmark:after {
        display: block;
    }

    /* Style the checkmark/indicator */
    .customcheck .checkmark:after {
        left: 8px;
        top: 4px;
        width: 5px;
        height: 10px;
        border: solid white;
        border-width: 0 3px 3px 0;
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        transform: rotate(45deg);
    }

    .customradio {
        position: relative;
        padding-left: 30px;
        margin: 5px 15px 10px 5px;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    /* Hide the browser's default radio button */
    .customradio input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
    }

    /* Create a custom radio button */
    .radiomark {
        position: absolute;
        top: 0;
        left: 0;
        height: 20px;
        width: 20px;
        background-color: #fff;
        border-radius: 50%;
    }

    /* On mouse-over, add a grey background color */
    .customradio:hover input~.radiomark {
        background-color: #fff;
    }

    /* When the radio button is checked, add a blue background */
    .customradio input:checked~.radiomark {
        background-color: #282471;
    }

    /* Create the indicator (the dot/circle - hidden when not checked) */
    .radiomark:after {
        content: "";
        position: absolute;
        display: none;
    }

    /* Show the indicator (dot/circle) when checked */
    .customradio input:checked~.radiomark:after {
        display: block;
    }

    /* Style the indicator (dot/circle) */
    .customradio .radiomark:after {
        top: 6px;
        left: 6px;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: white;
    }

    input#delarationInput {
        width: auto !important;
        padding: 0 !important;
        border: none;
        border-bottom: 1px dashed #999;
        margin: 0 8px;
        outline: none;
    }

    select#declarerRole {
        padding: 5px;
        margin: 0 8px;
        font-size: 15px;
        outline: none;
    }

    .declaration-statement {
        margin: 10px 0;
    }

    button.submit-btn {
        background: #282471;
        color: white;
        border: none;
        padding: 10px 20px;
        margin: 20px 0;
        text-transform: uppercase;
    }

    .form-footer {
        text-align: center;
    }

    .form-footer-top {
        color: #282471;
        font-size: 30px;
        font-weight: 600;
    }

    .form-footer-bottom {
        background: #282471;
        color: white;
        padding: 12px;
    }

    .form-footer-affiliation {
        font-size: 20px;
        font-weight: 800;
        text-transform: uppercase;
    }

    input#upload-documents {
        margin: 10px 0;
    }
    .copyright-text,.copyright-text a{
        color: #fff;
    }
    .footer-linksection .footer-link{
        color: #fff;
    }
    .singlepage-content,.singlepage-heading{
        color: #000;
    }
    .form-section-headline,.form-label{
        color: #000;
    }
    .customradio{
        color: #000 !important;
    }
    .customcheck,.form-label,.declaration-statement,.declaration-note{
        color: #000;
    }
    @media  only screen and (max-width: 767px) {
        .admission-logo {
            width: 40% !important;
        }

        .admission-title {
            font-size: 24px !important;
        }

        .online-form {
            font-size: 14px;
        }

        #admissionForm input[type="text"],
        #admissionForm input[type="date"] {
            margin-bottom: 5px;
        }

        .form-section-headline {
            font-size: 16px;
        }

        .form-footer-top {
            font-size: 22px;
        }

        .form-footer-bottom {
            font-size: 12px;
        }

        .form-footer-affiliation {
            font-size: 13px;
        }
    }
</style>
<?php $__env->startSection('main-content'); ?>
    <section id="admissionBanner">
        <img class="beyond-img" src="<?php echo e(asset('uploads/admission/'.$admission->image)); ?>">
    </section>
    <section id="admissionForm" class="mb-5">
        <div class="container">
            <div class="singlepage-heading">
                <h1 class="pt-4">Admission</h1>
            </div>
            <div class="singlepage-heading-bar"></div>
            <div class="singlepage-content mb-4">
                <?php echo $admission->description; ?>

            </div>
            <div class="form-download pb-2">
                <h6>ADMISSION FORM DOWNLOAD</h6>
                <div class="singlepage-heading-bar"></div>
                <div class="hamro-shadow">
                    <div class="">
                        <a href="<?php echo e(asset('uploads/admission/'.$admission->pdf)); ?>" download class="bbtn  btn btn-info btn-sm"
                           role="button" aria-pressed="true"><i class="fa fa-download"></i> Download</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="admissionForm" class="mb-5">
        <div class="container">
            <div class="apply-online">
                <h6>OR APPLY ONLINE</h6>
                <?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="singlepage-heading-bar"></div>
                <div class="online-form">
                    <form id="form" action="<?php echo e(url('student-form')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="admissionform-header text-center">
                            <div class="row">
                                <div class="col-md-2">

                                </div>
                                <div class="col-md-8 mt-auto">
                                    <div class="admission-title">
                                        Online Admission Form
                                    </div>
                                    <hr>
                                </div>
                                <div class="col-md-2 my-auto">
                                    <div class="alert"></div>
                                    <div id='img_container'>
                                        <img id="preview" src="https://svgsilh.com/svg_v2/1299805.svg" alt="your image"  title='' /></div>
                                    <div class="input-group">
                                        <div class="custom-file">
                                            <input type="file" id="inputGroupFile01" name="inputGroupFile01" class="imgInp custom-file-input"
                                                   aria-describedby="inputGroupFileAddon01" required>
                                            <label class="custom-file-label" for="inputGroupFile01">Upload PP
                                                Photo</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-body">
                            <div class="form-section-headline">
                                Student's Personal Information
                            </div>
                            <div class="form-bar"></div>
                            <div class="form-div">
                                <div class="form-label">Student's Full Name:</div>
                                <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required>
                            </div>
                            <div class="form-div">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-label">Date of Birth:</div>
                                        <input type="date" name="dob" id="dob" value="<?php echo e(old('dob')); ?>">
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-label">Place of Birth:</div>
                                        <input type="text" name="pob" id="pob" value="<?php echo e(old('pob')); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-label">Gender:</div>
                                        <label class="customradio">
                                            Male
                                            <input type="radio" name="gender" value="male" id="male">
                                            <span class="radiomark"></span>
                                        </label>
                                        <label class="customradio">
                                            Female
                                            <input type="radio" name="gender" value="female" id="female">
                                            <span class="radiomark"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-div">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-label">Nationality:</div>
                                        <input type="text" name="nationality" id="nationality" value="<?php echo e(old('nationality')); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-label">Mother Tongue:</div>
                                        <input type="text" name="mothertongue" id="mothertongue" value="<?php echo e(old('mothertongue')); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-label">Religion:</div>
                                        <input type="text" name="religion" id="religion" value="<?php echo e(old('religion')); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-div">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-label">Grade Applied For:</div>
                                        <input type="text" name="appliedgrade" id="appliedgrade" value="<?php echo e(old('appliedgrade')); ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-label">Academic Year:</div>
                                        <input type="text" name="academicyear" id="academicyear" value="<?php echo e(old('academicyear')); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-div">
                                <div class="form-label">Permanent Address:</div>
                                <input type="text" name="stdntprmntaddress" id="stdntprmntaddress" value="<?php echo e(old('stdntprmntaddress')); ?>">
                            </div>
                            <div class="form-div">
                                <div class="form-label">Current Address:</div>
                                <input type="text" name="stdntcurrentaddress" id="stdntcurrentaddress" value="<?php echo e(old('stdntcurrentaddress')); ?>">
                            </div>
                            <div class="form-section-headline">
                                Last Academic Information
                            </div>
                            <div class="form-bar"></div>
                            <textarea rows="5" name="lastinfo" id="lastinfo"
                                      placeholder="Specify School Name, Class Attended, Passed Year, and Percentage/Grade obtained"
                                      value="<?php echo e(old('lastinfo')); ?>">
                                         </textarea>
                            <div class="form-section-headline">
                                Co-Curricular Activities
                            </div>
                            <div class="form-bar"></div>
                            <textarea rows="5" name="activity" id="activity"
                                      placeholder="National Level, Zonal Level, District Level, School Level"
                                      value="<?php echo e(old('activity')); ?>">
                                         </textarea>
                            <div class="form-section-headline">
                                Medical Information
                            </div>
                            <div class="form-bar"></div>
                            <div class="form-div">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-label">Blood Group:</div>
                                        <input type="text" name="bloodgroup" id="bloodgroup" value="<?php echo e(old('bloodgroup')); ?>">
                                    </div>
                                    <div class="col-sm-6 col-md-4">
                                        <div class="form-label">Height:</div>
                                        <input type="text" name="height" id="height" value="<?php echo e(old('height')); ?>">
                                    </div>
                                    <div class="col-sm-6 col-md-4">
                                        <div class="form-label">Weight:</div>
                                        <input type="number" name="weight" id="weight" value="<?php echo e(old('weight')); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-div">
                                <div class="form-label">Please mention if any medical issue</div>
                                <input type="text" name="medicalissue" id="medicalissue" value="<?php echo e(old('medicalissue')); ?>">
                            </div>
                            <div class="form-section-headline">
                                Service Required
                            </div>
                            <div class="form-bar"></div>
                            <div class="form-div">
                                        <span class="form-label">
                                            Hostel Facility:
                                        </span>
                                <label class="customradio">
                                    Yes
                                    <input type="radio" name="hostel" value="Yes">
                                    <span class="radiomark"></span>
                                </label>
                                <label class="customradio">
                                    No
                                    <input type="radio" name="hostel" value="No">
                                    <span class="radiomark"></span>
                                </label>
                            </div>
                            <div class="form-div">
                                <span class="form-label">Transportation Service:</span>
                                <label class="customradio">
                                    Yes
                                    <input type="radio" name="transportation" value="Yes">
                                    <span class="radiomark"></span>
                                </label>
                                <label class="customradio">
                                    No
                                    <input type="radio" name="transportation" value="No">
                                    <span class="radiomark"></span>
                                </label>
                                <input type="text" name="pickup_point" id="pickup_point"
                                       placeholder="If yes, mention pickup point" value="<?php echo e(old('pickup_point')); ?>">
                            </div>
                            <div class="form-div">
                                <span class="form-label">Lunch:</span>
                                <label class="customradio">
                                    Yes
                                    <input type="radio" name="lunch" value="Yes">
                                    <span class="radiomark"></span>
                                </label>
                                <label class="customradio">
                                    No
                                    <input type="radio" name="lunch" value="No">
                                    <span class="radiomark"></span>
                                </label>
                                <input type="text" name="veg_nonveg" id="veg_nonveg"
                                       placeholder="If yes, Veg/Non-Veg" value="<?php echo e(old('veg_nonveg')); ?>">
                            </div>
                            <div class="form-div">
                                <span class="form-label">After School:</span>
                                <label class="customradio">
                                    Yes
                                    <input type="radio" name="afterschool" value="Yes">
                                    <span class="radiomark"></span>
                                </label>
                                <label class="customradio">
                                    No
                                    <input type="radio" name="afterschool" value="No">
                                    <span class="radiomark"></span>
                                </label>
                                <input type="text" name="after_school_program"
                                       placeholder="If yes, what kind of program" value="<?php echo e(old('after_school_program')); ?>">
                            </div>
                            <div class="form-section-headline">
                                Checklist of documents to be attached
                            </div>
                            <div class="form-bar"></div>
                            <label class="customcheck">
                                Birth Certificate
                                <input type="checkbox" name="check[]" value="birth_certificate">
                                <span class="checkmark"></span>
                            </label>
                            <label class="customcheck">
                                Transfer Certificate
                                <input type="checkbox" name="check[]" value="transfer_certificate">
                                <span class="checkmark"></span>
                            </label>
                            <label class="customcheck">
                                Migration Certificate
                                <input type="checkbox" name="check[]" value="migration_certificate">
                                <span class="checkmark"></span>
                            </label>
                            <label class="customcheck">
                                Character Certificate
                                <input type="checkbox" name="check[]" value="character_certificate">
                                <span class="checkmark"></span>
                            </label>
                            <label class="customcheck">
                                Report Card of Last Class
                                <input type="checkbox" name="check[]" value="report_card_of_last_class">
                                <span class="checkmark"></span>
                            </label>
                            <label class="customcheck">
                                Parents Citizenship
                                <input type="checkbox" name="check[]" value="parents_citizenship">
                                <span class="checkmark"></span>
                            </label>
                            <div class="form-div">
                                <div class="form-label">
                                    Upload your documents here [ Please attach all documents in a single
                                    file(.pdf/.doc/.docx/.zip) ]
                                </div>
                                <input type="file" name="upload" id="upload" required>
                            </div>

                            <div class="form-section-headline">
                                Parents/Guardians/Siblings Information
                            </div>
                            <div class="form-bar"></div>
                            <div class="form-div">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-label">Father's Name</div>
                                        <input type="text" name="fathername" id="fathername" value="<?php echo e(old('fathername')); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-label">Father's Contact Number</div>
                                        <input type="tel" name="fathercontact" id="fathercontact" value="<?php echo e(old('fathercontact')); ?>"
                                               minlength="10" maxlength="10">
                                    </div>
                                </div>
                            </div>
                            <div class="form-div">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-label">Mother's Name</div>
                                        <input type="text" name="mothername" id="mothername" value="<?php echo e(old('mothername')); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-label">Mother's Contact Number</div>
                                        <input type="tel" name="mothercontact" id="mothercontact" value="<?php echo e(old('mothercontact')); ?>"
                                               minlength="10" maxlength="10">
                                    </div>
                                </div>
                            </div>
                            <div class="form-div">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-label">Guardian's Name</div>
                                        <input type="text" name="guardianname" id="guardianname" value="<?php echo e(old('guardianname')); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-label">Guardian's Contact Number</div>
                                        <input type="tel" name="guardiancontact" id="guardiancontact"
                                               value="" minlength="10" maxlength="10" value="<?php echo e(old('guardiancontact')); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-div">
                                <div class="form-label">
                                    Sibling's Information
                                </div>
                                <textarea rows="4" name="sibling" id="sibling"
                                          placeholder="Their Name, Date of Birth, and school/college they are attending currently" value="<?php echo e(old('sibling')); ?>"></textarea>
                            </div>
                            <div class="form-div">
                                <div class="form-label">
                                    How did you hear about PWA School?
                                </div>
                                <textarea rows="4" name="hear" id="hear" value="<?php echo e(old('hear')); ?>"></textarea>
                            </div>
                            <hr>
                            <div class="form-section-headline">
                                Declaration:
                            </div>
                            <div class="form-bar"></div>
                            <div class="declaration-statement">
                                I <input id="delarationInput" type="text" name="delarationInput" value="<?php echo e(old('delarationInput')); ?>"> the
                                <select id="declareRole" name="declareRole" required>
                                    <option value="Parent">Parent</option>
                                    <option value="Guardian">Guardian</option>
                                    <option value="Student">Student</option>
                                </select> seeking admission in PWA School, solemnly declare that the above given
                                information is true to my knowledge and I will strictly abideby the rules and
                                regulations in force and that may be framed hereafter, and will not indulge in
                                any unsocial activities. I will avoid any act of indiscipline and breach of
                                rules. I further agree to reimburse any furniture, apparatus, etc. which may
                                cause by carelessness or wantonness on my part.
                            </div>
                            <div class="declaration-statement">
                                <li>
                                    In case of medical emergency in school premises, respective class teacher or
                                    medical supervisor will offer immediate first aid and/or take the student to
                                    a nearby hospital and inform the parent/guardian as soon as possible. All
                                    the medical expenses occured during should by borne by parents/guardian at
                                    the time, which later may be claimed as per Group Personnel Accidental
                                    Insurance policy for students.
                                </li>
                            </div>
                            <div class="declaration-statement">
                                <li>
                                    School has the right to use student's photograph (candid or professional
                                    shoot) in any of the school's collateral or promotional purpose. For any
                                    objection to it, the administration can be furnished a letter at the time of
                                    admission.
                                </li>
                            </div>
                            <div class="declaration-note">
                                (Only duly filled application along with the required documents will be accepted
                                by the school)
                            </div>
                            <div class="declaration-statement">
                                <label class="customcheck">
                                    I read the above statements and I strongly agree to them.( * Compulsary)
                                    <input type="checkbox" name="declaration2" id="declaration2" value="Yes" required>
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <div class="form-div">
                                <div class="form-section-headline">Applicant's Contact Details:</div>
                                <div class="form-bar"></div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-label">Contact Number</div>
                                        <input type="tel" name="applicantscontact" id="applicantscontact"
                                               minlength="10" maxlength="10" value="<?php echo e(old('applicantscontact')); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-label">Email</div>
                                        <input type="email" name="applicantsemail" id="applicantsemail"
                                               value="<?php echo e(old('applicantsemail')); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-div">
                                <button type="submit" class="submit-btn">Submit Application</button>
                            </div>
                        </div>
                        <div class="form-footer">
                            <div class="form-footer-top">
                                www.PrarambhaworldSchool.edu.np
                            </div>
                            <div class="form-footer-bottom">
                                <div class="form-footer-affiliation">
                                    Affiliated to HSEB Board , Kathmandu, Nepal
                                </div>
                                <div>
                                    Nepaltar ( Near Government Headquater ), Kathmandu, Nepal. Ph: xx - xxxxxx /
                                    xxxxx, E-mail: info@PWA.edu.np, PWAschoolktm@gmail.com
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\prarambha\resources\views/frontend/admission.blade.php ENDPATH**/ ?>