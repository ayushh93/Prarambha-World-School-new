<?php $__env->startSection('main-content'); ?>
    <section id="homeAbout">
        <div class="container">
            <div class="row py-5">
                <div class="col-md-12">
                    <div class="home-abt-title wow fadeInLeft delay-0.5s ease animated">
                        <h6 class="large label">Policy</h6>
                        <div class="title-bar"></div>
                        <div class="home-abt-sub-title-dark">

                            <body style="background-color:teal;">
                            <p>
                               <?php echo $policy->description; ?>

                            </p>
                        </div>
                    </div>
                </div>




            </div>
        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\prarambha\resources\views/frontend/policy.blade.php ENDPATH**/ ?>