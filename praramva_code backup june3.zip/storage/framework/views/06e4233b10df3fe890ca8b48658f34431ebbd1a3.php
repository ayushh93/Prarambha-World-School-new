<?php $__env->startSection('main-content'); ?>
    <section id="homeGallery" class="container-fluid mx-auto">
        <div class="container">
            <h1 class="section-title label pb-12">Gallery</h1>
            <div class="title-bar w-full mx-auto"></div>
            <div id="galleryFlex" class="d-flex flex-wrap gap-3 justify-content-between align-items-center max-w-5xl mx-auto px-6 mt-4">
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a data-fancybox="gallery" href="https://lipsum.app/id/66/1600x1200">
                    <img class="rounded mb-2" src="https://lipsum.app/id/66/200x150">
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/pwsedu/praramva_code/resources/views/frontend/gallery.blade.php ENDPATH**/ ?>