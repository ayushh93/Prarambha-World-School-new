<?php $__env->startSection('main-content'); ?>
    <section id="homeAbout">
        <div class="container">
            <div class="row py-5">
                <div class="col-md-6">
                    <div class="home-abt-title wow fadeInLeft delay-0.5s ease animated">
                        <h1 class="large label">Kindergarten</h1>
                        <div class="title-bar"></div>
                        <div class="home-abt-sub-title-dark">

                            <body style="background-color:teal">
                            <p>
                                <?php echo $kinder->description; ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <a href="#">
                        <img src="<?php echo e(asset('uploads/kinder/'.$kinder->image)); ?>" class="rounded" width="100%" height="300">
                        <div class="home-abt-text wow fadeInRight delay-0.4s ease animated">
                        </div>
                </div>
            </div>
        </div>

        <section id="portfolioPage" class="section-padd">
            <div class="container">
                <ul class="nav nav-tabs justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#tab0">Classroom</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tab1">Playgroup</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tab2">Hygenic meal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tab3">Progress Report</a>
                    </li>

                </ul>

                <div class="tab-content">
                    <div id="tab0" class="tab-pane fade show active">
                        <div class="row">
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port0">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624509881.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port0">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624509881.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">

                                                        </div>
                                                        <div class="portfolio-li">

                                                        </div>
                                                        <div class="portfolio-li">

                                                        </div>
                                                        <div class="portfolio-li">

                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial",sans-serif;
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA"></span><br>
                                                            </p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port1">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624612605.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port1">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624612605.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA"></span><br>
                                                            </p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port2">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624613263.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port2">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624613263.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA"></span><br>
                                                            </p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port3">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624613384.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port3">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624613384.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">

                                                        </div>
                                                        <div class="portfolio-li">

                                                        </div>
                                                        <div class="portfolio-li">

                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,sans-serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA"></span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port4">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624613568.jpg">
                                        <!-- <div class="portfolio-item-detail">
                                    <div class="portfolio-item-title">

                                    </div>
                                    <div class="portfolio-item-location">

                                    </div>
                                </div> -->
                                    </div>
                                </a>
                                <div class="modal" id="port4">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624613568.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA"></span><br>
                                                            </p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port5">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624615025.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port5">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624615025.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b> </b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA"></span><br>
                                                            </p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port6">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1627533459.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port6">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1627533459.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial",sans-serif;
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA"></span><br>
                                                            </p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="tab1" class="tab-pane">
                        <div class="row">
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port7">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624510107.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port7">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624510107.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b> </b>
                                                            <p>
                                                            <p><span style="font-size:10.5pt;font-family:"
                                                                     arial","sans-serif";=""
                                                                mso-fareast-font-family:"times="" new=""
                                                                roman";mso-ansi-language:en-us;mso-fareast-language:=""
                                                                en-us;mso-bidi-language:ar-sa"="">
                                                                <b>22,371.61 </b>sq.mt. built-up area in
                                                                6

                                                                facilities.</span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port8">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624512508.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port8">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624512508.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;line-height:115%;
font-family:&quot;Arial&quot;,sans-serif;mso-fareast-font-family:Calibri;mso-fareast-theme-font:
minor-latin;mso-ansi-language:EN-US;mso-fareast-language:EN-US;mso-bidi-language:
NE"></span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port9">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624596350.JPG">

                                    </div>
                                </a>
                                <div class="modal" id="port9">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624596350.JPG">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;line-height:115%;
font-family:&quot;Arial&quot;,sans-serif;mso-fareast-font-family:Calibri;mso-fareast-theme-font:
minor-latin;mso-ansi-language:EN-US;mso-fareast-language:EN-US;mso-bidi-language:
NE">
                                                                                <b> </b>sq.ft. built-up area in 10&nbsp;
                                                                                floors,&nbsp;

                                                                            </span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port10">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624612730.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port10">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624612730.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA"></span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port11">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624612945.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port11">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624612945.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA"></span><br>
                                                            </p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port12">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624613060.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port12">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624613060.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b> </b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA">
                                                                </span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port13">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624615358.jpg">


                                    </div>
                                </a>
                                <div class="modal" id="port13">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624615358.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                                        <span style="font-size:11.0pt;font-family:&quot;Arial&quot;,sans-serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA"></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port14">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1625989581.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port14">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1625989581.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial",sans-serif;
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA"></span><br>
                                                            </p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="tab2" class="tab-pane">
                        <div class="row">
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port15">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1628139896.PNG">

                                    </div>
                                </a>
                                <div class="modal" id="port15">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> Bayalpata Hospital</h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1628139896.PNG">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">&nbsp;</span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port16">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624430331.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port16">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624430331.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,sans-serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA"></span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port17">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624433388.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port17">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624433388.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <div>

                                                            </div>
                                                            <div align="center">

                                                                <table class="MsoNormalTable" border="0"
                                                                       cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                    <tr>
                                                                        <td valign="top"
                                                                            style="padding:0in 9.0pt 0in 9.0pt">
                                                                            <p class="MsoNormal" style="margin-bottom:7.5pt;text-align:justify;line-height:
  normal"><span style="font-size:10.5pt;font-family:&quot;Arial&quot;,sans-serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">The project comprised of Clinical Skill lab,
                                                                                                    Auditorium, Library,
                                                                                                    Class
                                                                                                    Room, Training
                                                                                                    Center,
                                                                                                    Women’s Center
                                                                                                    Dental Block
                                                                                                    and Ward Extension
                                                                                                    having
                                                                                                    total area of
                                                                                                    23235.52 sq.m.
                                                                                                    Dental block is
                                                                                                    three
                                                                                                    story Hospital
                                                                                                    Building for
                                                                                                    Dental treatment
                                                                                                    having 132
                                                                                                    dental chairs
                                                                                                    capacities with
                                                                                                    facilities
                                                                                                    of operation theatre
                                                                                                    and
                                                                                                    other allied
                                                                                                    facilities
                                                                                                    required for dental
                                                                                                    treatment. This
                                                                                                    building is
                                                                                                    in implementation
                                                                                                    stage at
                                                                                                    present. Similarly,
                                                                                                    the
                                                                                                    Birthing (Women’s
                                                                                                    Center is
                                                                                                    six story Hospital
                                                                                                    Building
                                                                                                    for Birthing Centre
                                                                                                    having
                                                                                                    124 bed capacities
                                                                                                    with
                                                                                                    facilities of 3
                                                                                                    operation
                                                                                                    theatre, infertility
                                                                                                    department &amp;
                                                                                                    Training
                                                                                                    hall. Ward Extension
                                                                                                    Building is
                                                                                                    eight (8) story
                                                                                                    accommodates
                                                                                                    200 general beds, 24
                                                                                                    double
                                                                                                    rooms, 12 VIP Rooms
                                                                                                    for the patients,
                                                                                                    Class
                                                                                                    rooms, Meeting Rooms
                                                                                                    and
                                                                                                    Doctors
                                                                                                    Rooms.</span><br>
                                                                            </p>
                                                                        </td>
                                                                    </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port18">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624516726.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port18">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624516726.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">&nbsp;

                                                                                &nbsp;</span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port19">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624517312.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port19">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624517312.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,sans-serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA"></span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port20">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624598435.jpg">

                                    </div>
                                </a>
                                <div class="modal" id="port20">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"></h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624598435.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>L</b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b></b>
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b></b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA"></span><br>
                                                            </p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port21">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624612302.jpg">
                                        <div class="portfolio-item-detail">
                                            <div class="portfolio-item-title">
                                                Clinical Skill Lab cum Academic Block
                                            </div>
                                            <div class="portfolio-item-location">
                                                Dhulikhel Hospital, Dhulikhel, Kavre, Nepal
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <div class="modal" id="port21">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> Clinical Skill Lab cum Academic Block
                                                </h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624612302.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b>Client Name:</b> Dhulikhel Hospital, Dhulikhel,
                                                            Kavre,
                                                            Nepal
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Location:</b> Dhulikhel Hospital, Dhulikhel,
                                                            Kavre, Nepal
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Category:</b> Hospital
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Service Provided:</b> Survey, Planning,
                                                            Architectural &
                                                            Engineering Design works, Construction supervision &
                                                            monitoring works.
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b>Project Feature:</b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA">The
                                                                project
                                                                comprised of 3011 Sqmt. of total
                                                                floor area. It is 3 storeys Building
                                                                composed of
                                                                well facilitated theatre hall,
                                                                skill lab, canteen and
                                                                offices.</span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port22">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624612406.jpg">
                                        <div class="portfolio-item-detail">
                                            <div class="portfolio-item-title">
                                                Women's Center (Birthing Centre)
                                            </div>
                                            <div class="portfolio-item-location">
                                                Dhulikhel Hospital, Dhulikhel, Kavre, Nepal
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <div class="modal" id="port22">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> Women's Center (Birthing Centre)</h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624612406.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b>Client Name:</b> Dhulikhel Hospital, Dhulikhel,
                                                            Kavre,
                                                            Nepal
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Location:</b> Dhulikhel Hospital, Dhulikhel,
                                                            Kavre, Nepal
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Category:</b> Hospital
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Service Provided:</b> Survey, Planning,
                                                            Architectural &
                                                            Engineering Design works and Construction
                                                            supervision &
                                                            monitoring works.
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b>Project Feature:</b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA">The
                                                                project
                                                                comprised of 5638 Sqmt. of total
                                                                floor area. This is six <st1:place
                                                                    w:st="on">
                                                                    <st1:placename w:st="on">storey
                                                                    </st1:placename>
                                                                    <st1:placetype w:st="on">Hospital
                                                                    </st1:placetype>
                                                                    <st1:placetype w:st="on">Building
                                                                    </st1:placetype>
                                                                </st1:place>
                                                                for Birthing Centre having 100 bed
                                                                capacities
                                                                with facilities of 3 operation
                                                                theatre, infertility department &
                                                                Training
                                                                hall.</span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port23">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624612500.jpg">
                                        <div class="portfolio-item-detail">
                                            <div class="portfolio-item-title">
                                                Dental Block
                                            </div>
                                            <div class="portfolio-item-location">
                                                Dhulikhel Hospital, Dhulikhel, Kavre, Nepal
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <div class="modal" id="port23">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> Dental Block</h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624612500.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b>Client Name:</b> Dhulikhel Hospital, Dhulikhel,
                                                            Kavre,
                                                            Nepal
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Location:</b> Dhulikhel Hospital, Dhulikhel,
                                                            Kavre, Nepal
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Category:</b> Hospital
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Service Provided:</b> Survey, Planning,
                                                            Architectural &
                                                            Engineering Design works, and Construction
                                                            Supervision.
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b>Project Feature:</b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:"
                                                                     Arial","sans-serif";
                                                                mso-fareast-font-family:"Times New
                                                                Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                                EN-US;mso-bidi-language:AR-SA">The
                                                                project
                                                                comprised of 5067 Sqmt. of total
                                                                floor area. This is three <st1:place
                                                                    w:st="on">
                                                                    <st1:placename w:st="on">storey
                                                                    </st1:placename>
                                                                    <st1:placetype w:st="on">Hospital
                                                                    </st1:placetype>
                                                                    <st1:placetype w:st="on">Building
                                                                    </st1:placetype>
                                                                </st1:place>
                                                                for Dental treatment having 120 dental
                                                                chairs
                                                                capacities with facilities of
                                                                operation theatre and other allied
                                                                facilities
                                                                required for dental treatment.
                                                                This building is in implementation stage
                                                                at
                                                                present.</span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port24">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624613477.jpg">
                                        <div class="portfolio-item-detail">
                                            <div class="portfolio-item-title">
                                                Ashwins Medical College & Hospital
                                            </div>
                                            <div class="portfolio-item-location">
                                                Sainbu Bhaisepati, Lalitpur, Nepal
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <div class="modal" id="port24">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> Ashwins Medical College & Hospital</h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624613477.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b>Client Name:</b> Ashwins Medical College &
                                                            Hospital Pvt.
                                                            Ltd.
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Location:</b> Sainbu Bhaisepati, Lalitpur, Nepal
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Category:</b> Hospital
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Service Provided:</b> Survey, Planning,
                                                            Architectural &
                                                            Engineering Design works
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b>Project Feature:</b>
                                                            <p>
                                                            <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,sans-serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">The project is comprised of 750000 SqFt. Of
                                                                                total floor area. It is a 700 bed
                                                                                hospital and
                                                                                medical college to be
                                                                                constructed in approx. 120 Ropani land
                                                                                area at
                                                                                Bhaisepati, Lalitpur. It is
                                                                                equipped with facilities required as per
                                                                                Nepal
                                                                                Medical Council, Indian Medical
                                                                                Council and other international
                                                                                standards. It is
                                                                                compiled of Hospital, Academic
                                                                                and Hostel, three main blocks with an
                                                                                auditorium
                                                                                (500 cap.) and other service
                                                                                accessories viz. central plant house,
                                                                                treatment
                                                                                plants, Oxygen plant, Pharmacy
                                                                                block etc.</span><br></p>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <a href="#" data-toggle="modal" data-target="#port25">
                                    <div class="portfolio-item">
                                        <img class="portfolio-img"
                                             src="https://ewesnepal.com/uploads/catservice/1624613824.jpg">
                                        <div class="portfolio-item-detail">
                                            <div class="portfolio-item-title">
                                                1) Ward Extension Building, 2) OPD Floor Extension and 3) Hostel
                                                Building
                                            </div>
                                            <div class="portfolio-item-location">
                                                Dhulikhel, Kavre, Nepal
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <div class="modal" id="port25">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title"> 1) Ward Extension Building, 2) OPD
                                                    Floor
                                                    Extension and 3) Hostel Building</h4>
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-7">
                                                        <img class="project-modal-img"
                                                             src="https://ewesnepal.com/uploads/catservice/1624613824.jpg">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <div class="portfolio-li">
                                                            <b>Client Name:</b> Dhulikhel Hospital, Dhulikhel,
                                                            Kavre,
                                                            Nepal
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Location:</b> Dhulikhel, Kavre, Nepal
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Category:</b> Hospital
                                                        </div>
                                                        <div class="portfolio-li">
                                                            <b>Service Provided:</b> Survey, Planning,
                                                            Architectural &
                                                            Engineering Design works, and partial supervision.
                                                        </div>
                                                        <div class="portfolio-li mt-3">
                                                            <b>Project Feature:</b>
                                                            <p>
                                                                <div>

                                                                    <table cellspacing="0" cellpadding="0"
                                                                           hspace="0" vspace="0" align="center">
                                                                        <tbody>
                                                                        <tr>
                                                                            <td valign="top" align="left"
                                                                                style="padding-top:0in;padding-right:9.0pt;
  padding-bottom:0in;padding-left:9.0pt">
                                                            <p class="MsoNormal" style="text-align:justify;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-left:center;mso-element-top:
  17.8pt;mso-height-rule:exactly"><span style="font-size:11.0pt;font-family:
  " Arial","sans-serif"">This project is composed of three different buildings
                                                                having total of
                                                                about 33588
                                                                sft. Floor area. The
                                                                significant feature
                                                                of this
                                                                project is these
                                                                buildings
                                                                are located in the
                                                                hilly
                                                                terrain with steep
                                                                slope
                                                                and are designed as
                                                                per the
                                                                existing
                                                                environmental
                                                                aspects. The land
                                                                used for
                                                                the buildings was
                                                                thought of
                                                                no use primarily due
                                                                to its
                                                                terrible slopes. The
                                                                natural landscape
                                                                has been
                                                                retained and
                                                                reworked
                                                                without disturbing
                                                                much.
                                                                <o:p></o:p></span>
                                                            </p>
                                                            </td>
                                                            </tr>
                                                            </tbody>
                                                            </table>

                                                        </div>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-4">
                            <a href="#" data-toggle="modal" data-target="#port26">
                                <div class="portfolio-item">
                                    <img class="portfolio-img"
                                         src="https://ewesnepal.com/uploads/catservice/1625989079.jpg">
                                    <div class="portfolio-item-detail">
                                        <div class="portfolio-item-title">
                                            Lung Centre (Respiratory Centre)
                                        </div>
                                        <div class="portfolio-item-location">
                                            Dhulikhel Hospital, Dhulikhel, Kavre, Nepal
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <div class="modal" id="port26">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title"> Lung Centre (Respiratory Centre)</h4>
                                            <button type="button" class="close"
                                                    data-dismiss="modal">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-7">
                                                    <img class="project-modal-img"
                                                         src="https://ewesnepal.com/uploads/catservice/1625989079.jpg">
                                                </div>
                                                <div class="col-md-5">
                                                    <div class="portfolio-li">
                                                        <b>Client Name:</b> Dhulikhel Hospital
                                                    </div>
                                                    <div class="portfolio-li">
                                                        <b>Location:</b> Dhulikhel Hospital, Dhulikhel,
                                                        Kavre, Nepal
                                                    </div>
                                                    <div class="portfolio-li">
                                                        <b>Category:</b> Hospital
                                                    </div>
                                                    <div class="portfolio-li">
                                                        <b>Service Provided:</b> Survey, Planning,
                                                        Architectural &
                                                        Engineering Design works, Cost estimates.
                                                    </div>
                                                    <div class="portfolio-li mt-3">
                                                        <b>Project Feature:</b>
                                                        <p>
                                                            <div>

                                                                <table cellspacing="0" cellpadding="0"
                                                                       hspace="0" vspace="0" align="left">
                                                                    <tbody>
                                                                    <tr>
                                                                        <td valign="top" align="left"
                                                                            style="padding-top:0in;padding-right:9.0pt;
  padding-bottom:0in;padding-left:9.0pt">
                                                        <p class="MsoNormal" style="text-align:justify;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-left:-31.5pt;mso-element-top:
  12.85pt;mso-height-rule:exactly"><span style="font-size:11.0pt;font-family:
  " Arial",sans-serif">The project comprised of 2355.80 sq.mt. of total floor
                                                            area. This is four
                                                            storey
                                                            Hospital Building
                                                            accommodates COPD,
                                                            BPPAV,
                                                            Spirometry, Sleep
                                                            studies,
                                                            Emergency,
                                                            Laboratories,
                                                            Physiotherapy,
                                                            X-Ray,
                                                            Inpatient beds, and
                                                            Academic
                                                            facilities.<o:p>
                                                            </o:p>
                                                            </span></p>
                                                        </td>
                                                        </tr>
                                                        </tbody>
                                                        </table>

                                                    </div>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <a href="#" data-toggle="modal" data-target="#port27">
                            <div class="portfolio-item">
                                <img class="portfolio-img"
                                     src="https://ewesnepal.com/uploads/catservice/1627019742.jpg">
                                <div class="portfolio-item-detail">
                                    <div class="portfolio-item-title">
                                        100 Bed Expansion of Bir Hospital Building (JICA Funded Project)
                                    </div>
                                    <div class="portfolio-item-location">
                                        Bir Hospital, Kathmandu
                                    </div>
                                </div>
                            </div>
                        </a>
                        <div class="modal" id="port27">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title"> 100 Bed Expansion of Bir Hospital
                                            Building
                                            (JICA Funded Project)</h4>
                                        <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <img class="project-modal-img"
                                                     src="https://ewesnepal.com/uploads/catservice/1627019742.jpg">
                                            </div>
                                            <div class="col-md-5">
                                                <div class="portfolio-li">
                                                    <b>Client Name:</b> Overall project/construction
                                                    management
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Location:</b> Bir Hospital, Kathmandu
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Category:</b> Hospital
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Service Provided:</b> OCG, Japan
                                                </div>
                                                <div class="portfolio-li mt-3">
                                                    <b>Project Feature:</b>
                                                    <p>
                                                    <p><span style="font-size:11.0pt;font-family:"
                                                             Times New Roman",serif;
                                                        mso-fareast-font-family:"Times New
                                                        Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                        EN-US;mso-bidi-language:AR-SA">This
                                                        project is
                                                        under the JICA Grant Assistance
                                                        in health sector infrastructure damaged
                                                        by April
                                                        2015earthquake. The 4 story 100
                                                        bedded RCC framed structure hospital
                                                        building
                                                        with basement compartment for
                                                        services. Total built-up area in 4 plus
                                                        <b>1
                                                            basement</b> floors is 35154
                                                        sq.ft. having 100 bed capacity with all
                                                        required
                                                        amenities. </span><br></p>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="tab3" class="tab-pane">
                <div class="row">
                    <div class="col-sm-6 col-xl-4">
                        <a href="#" data-toggle="modal" data-target="#port28">
                            <div class="portfolio-item">
                                <img class="portfolio-img"
                                     src="https://ewesnepal.com/uploads/catservice/1624509627.jpg">
                                <div class="portfolio-item-detail">
                                    <div class="portfolio-item-title">
                                        Lo Mustang Resort
                                    </div>
                                    <div class="portfolio-item-location">
                                        Muktinath, Varagung Muktichhetra Rural Municipality-1, Mustang,
                                        Nepal
                                    </div>
                                </div>
                            </div>
                        </a>
                        <div class="modal" id="port28">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title"> Lo Mustang Resort</h4>
                                        <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <img class="project-modal-img"
                                                     src="https://ewesnepal.com/uploads/catservice/1624509627.jpg">
                                            </div>
                                            <div class="col-md-5">
                                                <div class="portfolio-li">
                                                    <b>Client Name:</b>
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Location:</b> Muktinath, Varagung Muktichhetra
                                                    Rural
                                                    Municipality-1, Mustang, Nepal
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Category:</b> Hotel and Resort
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Service Provided:</b>
                                                </div>
                                                <div class="portfolio-li mt-3">
                                                    <b>Project Feature:</b>
                                                    <p>
                                                    <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">The project comprised of 24,904.37</span><span style="font-size:12.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:
&quot;Times New Roman&quot;;color:red;mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA"> </span><span style="font-size:12.0pt;font-family:
&quot;Arial&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:
EN-US;mso-fareast-language:EN-US;mso-bidi-language:AR-SA">Sq.Ft.</span><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA"> of total floor area with 20 Deluxe Rooms and 12 Suite
                                                                                Rooms, Restaurant, Staff quarter, Spa,
                                                                                kitchen
                                                                                garden and Apple plantation,
                                                                                walking trail, tented camp, helipad and
                                                                                parking
                                                                                with land area of 474,639 Sq.
                                                                                Ft. (87 Ropani</span><span style="font-size:12.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">)</span><span style="font-size:11.0pt;
font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:&quot;Times New Roman&quot;;
mso-ansi-language:EN-US;mso-fareast-language:EN-US;mso-bidi-language:AR-SA">. The
                                                                                building has been designed in green
                                                                                building
                                                                                concept meeting to the requirement
                                                                                of the IGBC/USGBC.</span><br></p>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <a href="#" data-toggle="modal" data-target="#port29">
                            <div class="portfolio-item">
                                <img class="portfolio-img"
                                     src="https://ewesnepal.com/uploads/catservice/1624510345.jpg">
                                <div class="portfolio-item-detail">
                                    <div class="portfolio-item-title">
                                        Hotel Lo Mustang
                                    </div>
                                    <div class="portfolio-item-location">
                                        Nursing Chowk, Thamel, Kathmandu, Nepal
                                    </div>
                                </div>
                            </div>
                        </a>
                        <div class="modal" id="port29">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title"> Hotel Lo Mustang</h4>
                                        <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <img class="project-modal-img"
                                                     src="https://ewesnepal.com/uploads/catservice/1624510345.jpg">
                                            </div>
                                            <div class="col-md-5">
                                                <div class="portfolio-li">
                                                    <b>Client Name:</b> Hotel Lo Mustang Pvt. Ltd,
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Location:</b> Nursing Chowk, Thamel, Kathmandu,
                                                    Nepal
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Category:</b> Hotel and Resort
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Service Provided:</b> A/E Planning & Design,
                                                    project
                                                    management
                                                </div>
                                                <div class="portfolio-li mt-3">
                                                    <b>Project Feature:</b>
                                                    <p>
                                                    <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,sans-serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">This is a 10 story Hotel Building located at a
                                                                                tourist hub, Thanmel in the capital city
                                                                                of
                                                                                Kathmandu composed of 64,467<b>
                                                                                </b>sq.ft.
                                                                                built-up area in 10&nbsp; floors,&nbsp;
                                                                                having 87 Guest Rooms, Restaurant,
                                                                                Health club,
                                                                                Seminar halls and
                                                                                parking, . The building is fully
                                                                                equipped with
                                                                                all required modern
                                                                                facilities</span><br></p>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <a href="#" data-toggle="modal" data-target="#port30">
                            <div class="portfolio-item">
                                <img class="portfolio-img"
                                     src="https://ewesnepal.com/uploads/catservice/1624523040.jpg">
                                <div class="portfolio-item-detail">
                                    <div class="portfolio-item-title">
                                        Hotel Arts Pvt. Ltd.
                                    </div>
                                    <div class="portfolio-item-location">
                                        Thamel, Kathmandu, Nepal
                                    </div>
                                </div>
                            </div>
                        </a>
                        <div class="modal" id="port30">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title"> Hotel Arts Pvt. Ltd.</h4>
                                        <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <img class="project-modal-img"
                                                     src="https://ewesnepal.com/uploads/catservice/1624523040.jpg">
                                            </div>
                                            <div class="col-md-5">
                                                <div class="portfolio-li">
                                                    <b>Client Name:</b> Hotel Arts Pvt. Ltd
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Location:</b> Thamel, Kathmandu, Nepal
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Category:</b> Hotel and Resort
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Service Provided:</b> A/E Planning & Design,
                                                    overall
                                                    project management, Financial Management,
                                                </div>
                                                <div class="portfolio-li mt-3">
                                                    <b>Project Feature:</b>
                                                    <p>
                                                    <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,sans-serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">This is a 10 story Hotel Building located at
                                                                                Thamel in the capital city of Kathmandu
                                                                                composed
                                                                                of 48,445<b> </b>sq.ft. built-up area in
                                                                                10
                                                                                floors,&nbsp;
                                                                                having 60 Guest Rooms, Restaurant,
                                                                                Health club,
                                                                                Seminar halls and
                                                                                parking, . The building is fully
                                                                                equipped with
                                                                                all required modern
                                                                                facilities</span><br></p>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <a href="#" data-toggle="modal" data-target="#port31">
                            <div class="portfolio-item">
                                <img class="portfolio-img"
                                     src="https://ewesnepal.com/uploads/catservice/1624612005.jpg">
                                <div class="portfolio-item-detail">
                                    <div class="portfolio-item-title">
                                        Serene Resort (P.) Ltd. – View Tower/ Guest
                                    </div>
                                    <div class="portfolio-item-location">
                                        Nagarkot, Bhaktapur
                                    </div>
                                </div>
                            </div>
                        </a>
                        <div class="modal" id="port31">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title"> Serene Resort (P.) Ltd. – View Tower/
                                            Guest
                                        </h4>
                                        <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <img class="project-modal-img"
                                                     src="https://ewesnepal.com/uploads/catservice/1624612005.jpg">
                                            </div>
                                            <div class="col-md-5">
                                                <div class="portfolio-li">
                                                    <b>Client Name:</b> Serene Resort, Pvt Ltd.
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Location:</b> Nagarkot, Bhaktapur
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Category:</b> Hotel and Resort
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Service Provided:</b> Survey, Planning, A & E
                                                    design, and
                                                    construction supervision.
                                                </div>
                                                <div class="portfolio-li mt-3">
                                                    <b>Project Feature:</b>
                                                    <p>
                                                    <p><span style="font-size:11.0pt;font-family:&quot;Arial&quot;,sans-serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">This building is designed at Nagarkot for view
                                                                                tower cum deluxe guest rooms and is the
                                                                                tallest
                                                                                building in that area. The
                                                                                designed facilities comprised of 22193
                                                                                SqFt. of
                                                                                total floor area spread in 12
                                                                                floor. The development also consists of
                                                                                six
                                                                                numbers of Cottages. The building
                                                                                is designed to give modern outlook to
                                                                                both
                                                                                exterior and interior. The interiors
                                                                                of the building comprised of flooring,
                                                                                false
                                                                                ceiling, electrical and
                                                                                communication, air-conditioning and
                                                                                furniture
                                                                                &amp; furnishing works.&nbsp;</span><br>
                                                    </p>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <a href="#" data-toggle="modal" data-target="#port32">
                            <div class="portfolio-item">
                                <img class="portfolio-img"
                                     src="https://ewesnepal.com/uploads/catservice/1624613936.jpg">
                                <div class="portfolio-item-detail">
                                    <div class="portfolio-item-title">
                                        Fuji Guest House
                                    </div>
                                    <div class="portfolio-item-location">
                                        Thamel, Kathmandu, Nepal
                                    </div>
                                </div>
                            </div>
                        </a>
                        <div class="modal" id="port32">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title"> Fuji Guest House</h4>
                                        <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <img class="project-modal-img"
                                                     src="https://ewesnepal.com/uploads/catservice/1624613936.jpg">
                                            </div>
                                            <div class="col-md-5">
                                                <div class="portfolio-li">
                                                    <b>Client Name:</b> Mr. & Mrs. Pradeep Pakhrin
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Location:</b> Thamel, Kathmandu, Nepal
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Category:</b> Hotel and Resort
                                                </div>
                                                <div class="portfolio-li">
                                                    <b>Service Provided:</b> Survey, Planning,
                                                    Architectural &
                                                    Engineering Design works and Construction
                                                    supervision &
                                                    monitoring works.
                                                </div>
                                                <div class="portfolio-li mt-3">
                                                    <b>Project Feature:</b>
                                                    <p>
                                                    <p><span style="font-size:11.0pt;font-family:"
                                                             Arial","sans-serif";
                                                        mso-fareast-font-family:"Times New
                                                        Roman";mso-ansi-language:EN-US;mso-fareast-language:
                                                        EN-US;mso-bidi-language:AR-SA">Fuji
                                                        Guest House
                                                        consists of 45 luxury Guest
                                                        Rooms and studio apartment with total
                                                        floor area
                                                        of 10,000 sq.ft. </span><br></p>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\prarambha\resources\views/frontend/kinder.blade.php ENDPATH**/ ?>