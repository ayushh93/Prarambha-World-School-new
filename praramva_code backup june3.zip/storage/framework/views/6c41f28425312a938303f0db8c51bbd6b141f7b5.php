<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
<?php $__env->startSection('main-content'); ?>
     <div class="accordion-content">
            <h2>FAQ</h2>
            
            <?php if($faqs): ?>
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="accordion-item">
                <header class="item-header">
                    <h4 class="item-question">
                        <?php echo $faq->title; ?>

                    </h4>
                    <div class="item-icon">
                        <i class='bx bx-chevron-down'></i>
                    </div>
                </header>
                <div class="item-content">
                    <p class="item-answer">
                         <?php echo $faq->description; ?>

                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
           
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/prarambha/praramva_code/resources/views/frontend/faq.blade.php ENDPATH**/ ?>