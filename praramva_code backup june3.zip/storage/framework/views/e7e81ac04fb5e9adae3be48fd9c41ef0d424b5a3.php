<?php $__env->startSection('main-content'); ?>
    <div class="pd-ltr-20">
        <div class="row">
            <div class="col-xl-3 mb-30">
                <div class="card-box height-100-p widget-style1">
                    <a href="<?php echo e(route('onlineform.index')); ?>">
                        <div class="d-flex flex-wrap align-items-center">
                            <div class="progress-data">
                                <div id="chart"></div>
                            </div>
                            <div class="widget-data">
                                <div class="h4 mb-0">
                                    <?php echo e(\App\Models\Onlineform::count()); ?>

                                </div>
                                <div class="weight-600 font-14">OnlineForm</div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-xl-3 mb-30">
                <div class="card-box height-100-p widget-style1">
                    <a href="<?php echo e(route('send.index')); ?>">
                        <div class="d-flex flex-wrap align-items-center">
                            <div class="progress-data">
                                <div id="chart2"></div>
                            </div>
                            <div class="widget-data">
                                <div class="h4 mb-0">
                                    <?php echo e(\App\Models\Send::count()); ?>

                                </div>
                                <div class="weight-600 font-14">Contact Message</div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>


























        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\prarambha\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>