<?php $__env->startSection('styles'); ?>
    <link  rel="stylesheet" href="<?php echo e(asset('assets/admin/src/styles/custom.css')); ?>"></link>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"
    />
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
    />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div id="container">
        <div id="header">
            <div id="monthDisplay"></div>
            <div>
                <button id="backButton"><</button>
                <button id="nextButton">></button>
            </div>
        </div>

        <div id="weekdays">
            <div>Sunday</div>
            <div>Monday</div>
            <div>Tuesday</div>
            <div>Wednesday</div>
            <div>Thursday</div>
            <div>Friday</div>
            <div>Saturday</div>
        </div>

        <div id="calendar"></div>

        <div id="newEventModal">
            <h2>New Event</h2>

            <input id="eventTitleInput" placeholder="Event Title" />

            <button id="saveButton">Save</button>
            <button id="cancelButton">Cancel</button>
        </div>

        <div id="deleteEventModal">
            <h2>Event</h2>

            <p id="eventText"></p>

            <button id="deleteButton">Delete</button>
            <button id="closeButton">Close</button>
        </div>

        <div id="modalBackDrop"></div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/admin/src/scripts/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\prarambha\resources\views/admin/calendar/index.blade.php ENDPATH**/ ?>