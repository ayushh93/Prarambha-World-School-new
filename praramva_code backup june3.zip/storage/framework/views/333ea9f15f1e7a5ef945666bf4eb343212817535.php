<?php $__env->startSection('main-content'); ?>
    <section class="news-events">
        <div class="container">
          <div class="row w-100 row-box">
            <div class="col-lg-8 col-md-7 border-right">
              <div class="news-events-details">
                <div class="news-events-image">
                  <img src="<?php echo e(asset('uploads/level/'.$event->image)); ?>" alt="News Event Image">
                </div>
                <div class="news-events-text">
                  <h4><?php echo $event->title; ?></h4>
                  <span><strong>Event Date:</strong> <?php echo e(\Carbon\Carbon::parse($event->level_date)->format('M d, Y')); ?>, &ensp;&ensp;&ensp; <strong>Level:</strong> <?php echo e($event->school->title); ?>

                  </span>
                  <p><?php echo $event->description; ?></p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-5">
              <div class="single-page-sidebar">
                <div class="single-page-sidebar-heading">
                  <h5>Related News & Events</h5>
                </div>
                <div class="single-page-sidebar-list">
                    <?php if($Recentevents): ?>
                  <ul>
                      <?php $__currentLoopData = $Recentevents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(url('event/'.$recent->slug)); ?>"><?php echo $recent->title; ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/pwsedu/praramva_code/resources/views/frontend/singleevent.blade.php ENDPATH**/ ?>