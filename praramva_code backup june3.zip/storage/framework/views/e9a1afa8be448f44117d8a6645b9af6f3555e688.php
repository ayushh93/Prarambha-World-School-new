<?php $__env->startSection('main-content'); ?>
    <?php if($sliders): ?>
    <section id="homeSliderSection">
        <div class="owl-carousel owl-theme" id="homeSlider">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <div class="slider-block" style="background-image: url('<?php echo e(asset('uploads/slider/'.$slider->image)); ?>')">
                    <div class="slider-overlay"></div>
                    <div class="slider-txt">
                        <div class="slider-caption">
                            <?php echo e($slider->title); ?>

                        </div>
                        <div class="slider-desc">
                            
                        </div>
                        <a href="<?php echo e($slider->link); ?>" class="slider-btn" target="_blank">Learn more</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if($about): ?>
    <section id="homeAbout">
        <div class="container">
            <div class="header-about">
                <h1 class="large label">About Us</h1>
                <div class="title-bar"></div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="about-image-index">
                        <img src="<?php echo e(asset('uploads/about/'.$about->image)); ?>" class="rounded">
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="about-text-index">
                        <p>
                            <?php echo Str::limit($about->description,300); ?>

                        </p>
                        <a href="<?php echo e(url('about-us')); ?>" class="link-btn large-btn">Learn more about us</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <section class="why-us">
        <div class="container">
          <h3 class="why-us-sub">Why <span class="why-us-sub-inner">Praramva World School</span>?</h3>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur commodi, quam non tempora eaque
            praesentium .</p>
          <div class="why-us-options">
              <?php if($whys): ?>
            <div class="row">
                <?php $__currentLoopData = $whys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $why): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-3 col-md-3 text-center">
                <div class="option">
                  <img src="<?php echo e(asset('uploads/why/'.$why->image)); ?>" alt="Image" class="img-fluid">
                </div>
                <div class="option-text">
                  <p><?php echo e($why->title); ?></p>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </section>


    <section id="homeEvents">
        <div class="container">
            <h2 class="section-title label">News and Events</h2>
            <div class="title-bar mx-auto"></div>
            <?php if($events): ?>
            <div class="owl-carousel owl-theme" id="eventSlider">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item wow fadeInUp delay-0.5s ease animated">
                    <div class="image-wrap">
                        <a href="javascript:">
                            <img src="<?php echo e(asset('uploads/event/'.$event->image)); ?>" />
                            <div class="event-overlay"></div>
                        </a>
                    </div>
                    <div class="event-bar">
                        <div class="event-block-date">
                            <div class="day"><?php echo e(\Carbon\Carbon::parse($event->event_date)->format('d')); ?></div>
                            <div class="month"><?php echo e(\Carbon\Carbon::parse($event->event_date)->format('M')); ?></div>
                            <div class="year"><?php echo e(\Carbon\Carbon::parse($event->event_date)->format('Y')); ?></div>
                        </div>
                        <div class="event-block-text">
                            <div class="event-block-title">
                                <?php echo $event->title; ?>

                            </div>
                            <div class="event-block-school">Higher Secondary</div>
                            <a class="event-block-btn" href="javascript:">More Info</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <div class="home-events-links">
                <a class="link-btn" href="<?php echo e(url('all-events')); ?>">View all events</a>
                <a class="link-btn" href="<?php echo e(url('calendar')); ?>">Calender</a>
                <a class="link-btn" href="<?php echo e(asset('uploads/admission/'.$admission->pdf)); ?>" download>
                    <i class="fa fa-download"></i>
                    Academic Calender 2022-2023
                </a>
            </div>
        </div>
    </section>
    
    <?php if($gallery): ?>
     <section id="homeGallery" class="container-fluid mx-auto">
        <div class="container">
          <h1 class="section-title label pb-12">Gallery</h1>
          <div class="title-bar w-full mx-auto"></div>
          <div class="gallery-flex">
            <div class="row">
                 <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-3 col-md-4">
                    <div class="gallery-image">
                      <a href="<?php echo e(asset('uploads/gallery/'.$gall->image)); ?>" data-fancybox="gallery">
                        <img src="<?php echo e(asset('uploads/gallery/'.$gall->image)); ?>" alt="Image">
                      </a>
                    </div>
                  </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </section>
    <?php endif; ?>

    <section id="homeAdmission" style="background-image: url('<?php echo e(asset('assets/frontend/img/s3.jpg')); ?>')">
        <div class="bg-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="home-admission-title wow fadeInUp delay-0.5s ease animated">
                        <h1 class="large label">Admissions</h1>
                        <div class="title-bar-white"></div>
                        <div class="home-abt-sub-title">
                            No entrance exams. No waiting list. All year enrollment.
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="home-admission-text wow fadeInUp delay-0.5s ease animated">
                        <p>
                            The Prarambha School has been providing a modern education
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                            sed do eiusmod tempor incididunt
                        </p>

                        <p>
                            <i class="fa fa-mobile-alt bg-success"></i> +977 <?php echo e($contact->phone); ?>

                        </p>
                        <p>
                            <i class="fa fa-envelope bg-success"></i> <?php echo e($contact->email); ?>

                        </p>

                        <a href="<?php echo e(url('admissions')); ?>" class="home-admission-btn1">Admissions</a>
                        <a href="<?php echo e(url('admissions')); ?>" class="home-admission-btn2">Register Online</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if($partners): ?>
    <section id="accreditation">
        <div class="container">
            <h2 class="section-title label">Accreditation</h2>
            <div class="title-bar mx-auto"></div>
            <div class="accreditation-grid">
                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accreditation-block wow fadeIn delay-0.5s ease animated">
                    <a href="javascript:" target="_blank" rel="nofollow">
                        <img src="<?php echo e(asset('uploads/partner/'.$partner->image)); ?>" />
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/pwsedu/praramva_code/resources/views/frontend/index.blade.php ENDPATH**/ ?>