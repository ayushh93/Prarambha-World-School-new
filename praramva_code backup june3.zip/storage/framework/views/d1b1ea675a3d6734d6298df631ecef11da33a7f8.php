<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/font-awesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/owl.carousel.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/owl.theme.default.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/material-design/css/material-design-iconic-font.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/hs-menu.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/animate.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/fancybox.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/custom.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/admission.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/responsive.css')); ?>" />
    <title>Praramva World School</title>
    <?php
        $logo = DB::table('logos')->select('*')->first();
    ?>
    <?php if($logo): ?>
    <link rel="icon" href="<?php echo e(asset('uploads/logo/'.$logo->image)); ?>">
    <?php endif; ?>
</head>

<body>
<div id="app">
    <header>
        <div id="mainMenu">
            <?php
                $logo = DB::table('logos')->select('*')->first();
            ?>
            <nav class="navbar navbar-expand-lg">
                <?php if($logo): ?>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('uploads/logo/'.$logo->image)); ?>" />
                </a>
                <?php endif; ?>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class=""><i class="fas fa-bars"></i></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown" href="<?php echo e(url('/')); ?>"> Home </a>
                            <span class="nav-underline"></span>
                        </li>
                        <li class="nav-item dropdown service-nav">
                            <a class="nav-link dropdown dropdown-toggle" data-toggle="dropdown" href="#">
                                About
                            </a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="<?php echo e(url('about-us')); ?>">About PWS</a>
                                <a class="dropdown-item" href="<?php echo e(url('policy')); ?>">Policies</a>
                                <a class="dropdown-item" href="<?php echo e(url('management')); ?>">Management</a>
                                <a class="dropdown-item" href="<?php echo e(url('faculty')); ?>">Faculty</a>
                                <a class="dropdown-item" href="<?php echo e(url('facilities')); ?>">Facilities</a>
                            </div>
                            <span class="nav-underline"></span>
                        </li>
                        <li class="nav-item dropdown service-nav">
                            <a class="nav-link dropdown dropdown-toggle" data-toggle="dropdown" href="#">
                                Courses
                            </a>
                            <div class="dropdown-menu">
                                <?php
                                    $courses = DB::table('courses')->select('*')->get();
                                ?>
                                <?php if($courses): ?>
                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item" href="<?php echo e(url('course/'.$course->slug)); ?>"><?php echo e($course->title); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <span class="nav-underline"></span>
                        </li>
                        <li class="nav-item dropdown service-nav">
                            <a class="nav-link dropdown dropdown-toggle" data-toggle="dropdown" href="#">
                                School
                            </a>
                            <div class="dropdown-menu">
                                <?php
                                    $schools = DB::table('schools')->select('*')->get();
                                ?>
                                <a class="dropdown-item" href="<?php echo e(url('kindergarten')); ?>">Kindergarten</a>
                                <?php if($schools): ?>
                                    <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item" href="<?php echo e(url('/'.$school->slug)); ?>"><?php echo e($school->title); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                <a class="dropdown-item" href="<?php echo e(url('gallery')); ?>">Gallery</a>
                            </div>
                            <span class="nav-underline"></span>
                        </li>
                        <li class="nav-item dropdown service-nav">
                            <a class="nav-link dropdown dropdown-toggle" data-toggle="dropdown" href="#">
                                Admissions
                            </a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="<?php echo e(url('overviews')); ?>">Overview</a>
                                <a class="dropdown-item" href="<?php echo e(url('school-fees')); ?>">School Fees</a>
                                <a class="dropdown-item" href="<?php echo e(url('regulations')); ?>">Regulations</a>
                                <a class="dropdown-item" href="<?php echo e(url('admissions')); ?>">Register Online</a>
                                <a class="dropdown-item" href="<?php echo e(url('contact-us')); ?>">Contact Registration</a>
                            </div>
                            <span class="nav-underline"></span>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown" href="<?php echo e(url('contact-us')); ?>"> Contact Us </a>

                            <span class="nav-underline"></span>
                        </li>
                    </ul>
                    <div class="nav-buttons">
                        <?php
                            $links = DB::table('links')->select('*')->where('status',1)->get();
                        ?>
                        <?php if($links): ?>
                            <div id="rightNavItems" class="float-right d-flex flex-row">
                                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key % 2 == 0): ?>
                                        <a title="<?php echo e($link->title); ?>" data-toggle="tooltip" data-placement="bottom" id="itemFb"
                                           class="btn btn-sm border-primary rounded-full">
                                            <i class="fab fa-<?php echo e($link->icon); ?>"></i>
                                        </a>
                                    <?php else: ?>
                                        <a title="<?php echo e($link->title); ?>" data-toggle="tooltip" data-placement="bottom" id="itemInsta"
                                           class="btn btn-sm mx-2 rounded-full">
                                            <i class="fab fa-<?php echo e($link->icon); ?>"></i>
                                        </a>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <div class="login-button">
                            <a href="http://praramvaworldschool.edu.np/admin/login" class="nav-login">LOGIN</a>
                        </div>
                        <div class="calendar-button">
                            <a href="<?php echo e(url('calendar')); ?>"><i class="fas fa-calendar-alt"></i></a>
                        </div>
                    </div>
                </div>
            </nav>
        </div>

        <div id="stickyContactInfo">
            <div class="tab mx-1">
                <span><i class="fa fa-check-circle"></i></span>
                <span><a href="<?php echo e(url('admissions')); ?>">Apply Now</a></span>
            </div>
            <div class="tab">
                <?php
                    $cont = DB::table('contacts')->select('*')->first();
                ?>
                <?php if($cont): ?>
                <span><i class="fa fa-phone"></i></span>
                <span><a href="tel:+">01-<?php echo e($cont->phone); ?></a></span>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="main-body">
       <?php echo $__env->yieldContent('main-content'); ?>
    </div>

    <footer>
        <div class="pre-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 footer-1st">
                        <div class="footer-name">
                            <?php if($logo): ?>
                                <a class="footer-logo" href="<?php echo e(url('/')); ?>">
                                    <img src="<?php echo e(asset('uploads/logo/'.$logo->image)); ?>" />
                                </a>
                            <?php endif; ?>
                        </div>
                        <?php
                            $contacts = DB::table('contacts')->select('*')->first();
                        ?>
                        <?php if($contacts): ?>
                        <div class="footer-list">
                            <i class="fa fa-map-marker-alt"></i>
                            <?php echo $contacts->address; ?>

                        </div>
                        <div class="footer-list">
                            <i class="fa fa-phone"></i>
                            +977-01-<?php echo $contacts->phone; ?>

                        </div>
                        <div class="footer-list">
                            <i class="fa fa-envelope"></i>
                            <?php echo $contacts->email; ?>

                        </div>
                        <?php endif; ?>

                        <?php
                            $linkss = DB::table('links')->select('*')->where('status',1)->get();
                        ?>
                        <?php if($linkss): ?>
                        <div class="footer-social">
                            <?php $__currentLoopData = $linkss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lnk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="javascript:" target="_blank">
                                <i class="fab fa-<?php echo e($lnk->icon); ?>"></i>
                            </a>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-3 footer-2nd">
                        <div class="footer-title">Quick Links</div>
                        <div class="footer-bar"></div>
                        <div class="footer-desc">
                            <ul style="padding: 0; list-style: none; margin-bottom: 0">
                                <li><a href="<?php echo e(url('about-us')); ?>">About PWS</a></li>
                                <li><a href="<?php echo e(url('calendar')); ?>">Calender</a></li>
                                <li><a href="<?php echo e(url('all-events')); ?>">Events</a></li>
                                <li><a href="">News</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 footer-3rd">
                        <div class="footer-title">Our School</div>
                        <div class="footer-bar"></div>
                        <div class="footer-desc">
                            <ul style="padding: 0; list-style: none; margin-bottom: 0">
                                <li><a href="<?php echo e(url('kindergarten')); ?>">Kindergarten</a></li>
                                <li><a href="<?php echo e(url('elementary')); ?>">Elementary</a></li>
                                <li><a href="<?php echo e(url('secondary')); ?>">Secondary</a></li>
                                <li><a href="<?php echo e(url('higher-secondary')); ?>">Higher Secondary</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 footer-4th">
                        <div class="footer-title">Contact Us</div>
                        <div class="footer-bar"></div>
                        <div class="footer-form">
                            <form id="footerContactForm" action="<?php echo e(url('send')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="title" required placeholder="Your Name" required />
                                <input type="email" name="email" required placeholder="Email Address"  required/>
                                <input type="text" name="subject" required placeholder="Subject" required />
                                <textarea type="text" name="description" rows="3" required placeholder="Message" required></textarea>
                                <button class="footer-btn" type="submit">SEND</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <div class="copyright-block">
                    <div class="copyright-text">
                        Copyright © <span id="dateHolder"></span> Praramva World School.
                        Developed by
                        <a href="https://www.itarrow.com">IT Arrow Pvt Ltd.</a>
                    </div>
                    <div class="footer-linksection">
                        <a class="footer-link" href="<?php echo e(url('/')); ?>">Home</a>
                        <a class="footer-link" href="<?php echo e(url('about-us')); ?>">About</a>
                        <a class="footer-link" href="<?php echo e(url('faqs')); ?>">Help</a>
                        <a id="back-to-top" href="#" class="back-to-top"><i class="fa fa-arrow-up"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div id="floating-social">
        <a class="floating-link" href="viber://chat?number=977981234567" data-toggle="tooltip" data-placement="top"
           title="9812345677">
            <i class="fab fa-viber"></i>
        </a>
        <a class="floating-link" href="https://api.whatsapp.com/send?phone=977981234567" target="_blank"
           data-toggle="tooltip" data-placement="top" title="98123456655">
            <i class="fab fa-whatsapp"></i>
        </a>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/owl.carousel.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/jquery.hsmenu.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/wow.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script>
<script>
    document.getElementById("dateHolder").innerHTML =
        new Date().getFullYear();
</script>
</body>

</html>
<?php /**PATH /home2/pwsedu/praramva_code/resources/views/layouts/frontend.blade.php ENDPATH**/ ?>