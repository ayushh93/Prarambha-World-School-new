<?php $__env->startSection('main-content'); ?>
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="page-header">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('onlineform.index')); ?>">Onlineform Data Lists</a></li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-md-6 col-sm-12 text-right">
                        <div class="dropdown">



                        </div>
                    </div>
                </div>
            </div>
            <!-- Default Basic Forms Start -->
            <div class="pd-20 card-box mb-30">
                <div class="clearfix">
                    <div class="pull-left">
                        <h4 class="text-blue h4">Student Details</h4>
                    </div>
                </div>
                <table class="table table-striped table-hover">
                    <div class="col-md-4 pull-right">
                        <div class="box box-primary">
                            <div class="box-header">
                                <h4> Image</h4>
                            </div>
                            <div class="box-body">
                                <img src="<?php echo e(asset('uploads/form'.'/'.$onlineform->image)); ?>" width="100%">
                            </div>
                        </div>
                    </div>

                    <ul class="list-group col-md-8">
                        <li class="list-group-item">
                            <strong>Name</strong> : <?php echo e($onlineform->name); ?>

                        </li>

                        <li class="list-group-item">
                            <strong>Date of Birth</strong> : <?php echo e($onlineform->dob); ?>

                        </li>

                        <li class="list-group-item">
                            <strong>Place of Birth</strong> : <?php echo $onlineform->pob; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Gender</strong> : <?php echo $onlineform->gender; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Nationality</strong> : <?php echo $onlineform->nationality; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Mother Tongue</strong> : <?php echo $onlineform->mothertongue; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Religion</strong> : <?php echo $onlineform->religion; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Grade Applied For</strong> : <?php echo $onlineform->appliedgrade; ?>

                        </li> <li class="list-group-item">
                            <strong>Academic Year</strong> : <?php echo $onlineform->academicyear; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Permanent Address</strong> : <?php echo $onlineform->stdntprmntaddress; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Current Address</strong> : <?php echo $onlineform->stdntcurrentaddress; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Last Academic Info</strong> : <?php echo $onlineform->lastinfo; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Co-cirricular Info</strong> : <?php echo $onlineform->activity; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Blood Group</strong> : <?php echo $onlineform->bloodgroup; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Height</strong> : <?php echo $onlineform->height; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Weight</strong> : <?php echo $onlineform->weight; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Medical Issues</strong> : <?php echo $onlineform->medicalissue; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Hostel Service</strong> : <?php echo $onlineform->hostel; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Transportation Service</strong> : <?php echo $onlineform->transportation; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Pickup point</strong> : <?php echo $onlineform->pickup_point; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Lunch</strong> : <?php echo $onlineform->lunch; ?>

                        </li>

                        <li class="list-group-item">
                            <strong>Veg/Non-veg</strong> : <?php echo $onlineform->veg_nonveg; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>After School</strong> : <?php echo $onlineform->afterschool; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>After School Program</strong> : <?php echo $onlineform->after_school_program; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Father's Name</strong> : <?php echo $onlineform->fathername; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Father's Contact No.</strong> : <?php echo $onlineform->fathercontact; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Mother's Name</strong> : <?php echo $onlineform->mothername; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Mother's Contact No.</strong> : <?php echo $onlineform->mothercontact; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Guardian's Name</strong> : <?php echo $onlineform->guardianname; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Guardian's Contact No.</strong> : <?php echo $onlineform->guardiancontact; ?>

                        </li>

                        <li class="list-group-item">
                            <strong>Sibling Info</strong> : <?php echo $onlineform->sibling; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Hear From</strong> : <?php echo $onlineform->hear; ?>

                        </li>

                        <li class="list-group-item">
                            <strong>Decleration Name</strong> : <?php echo $onlineform->delerationInput; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Decleration Role</strong> : <?php echo $onlineform->declareRole; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Applicant Contact No</strong> : <?php echo $onlineform->applicantscontact; ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Applicant Email</strong> : <?php echo $onlineform->applicantsemail; ?>

                        </li>

                        <li class="list-group-item">
                            <strong>Created</strong> : <?php echo e($onlineform->created_at->diffForHumans()); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Updated</strong> : <?php echo e($onlineform->updated_at->diffForHumans()); ?>

                        </li>
                    </ul>
                </table>

            </div>
            <!-- Default Basic Forms End -->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\prarambha\resources\views/admin/onlineform/show.blade.php ENDPATH**/ ?>