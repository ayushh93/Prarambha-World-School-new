<?php $__env->startSection('main-content'); ?>
    <section id="homeEvents">
        <div class="container">
            <h2 class="section-title label">All Events</h2>
            <div class="title-bar mx-auto"></div>
            <?php if($levels): ?>
                <div class="owl-carousel owl-theme" id="eventSlider">
                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item wow fadeInUp delay-0.5s ease animated">
                            <div class="image-wrap">
                                <a href="<?php echo e(url('event/'.$level->slug)); ?>">
                                    <img src="<?php echo e(asset('uploads/level/'.$level->image)); ?>" />
                                    <div class="event-overlay"></div>
                                </a>
                            </div>
                            <div class="event-bar">
                                <div class="event-block-date">
                                    <div class="day"><?php echo e(\Carbon\Carbon::parse($level->level_date)->format('d')); ?></div>
                                    <div class="month"><?php echo e(\Carbon\Carbon::parse($level->level_date)->format('M')); ?></div>
                                    <div class="year"><?php echo e(\Carbon\Carbon::parse($level->level_date)->format('Y')); ?></div>
                                </div>
                                <div class="event-block-text">
                                    <div class="event-block-title">
                                        <?php echo $level->title; ?>

                                    </div>
                                    <div class="event-block-school"><?php echo e($level->school->title); ?></div>
                                    <a class="event-block-btn" href="<?php echo e(url('event/'.$level->slug)); ?>">More Info</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/prarambha/praramva_code/resources/views/frontend/allEvent.blade.php ENDPATH**/ ?>