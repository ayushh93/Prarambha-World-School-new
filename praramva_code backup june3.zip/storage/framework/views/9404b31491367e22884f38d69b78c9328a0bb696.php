<?php $__env->startSection('main-content'); ?>
    <section id="homeAbout">
        <div class="container">
            <div class="row align-items-center py-5">
                <div class="col-md-6">
                    <div class="home-abt-title wow fadeInUp delay-0.5s ease animated">
                        <h1 class="large label">About Us</h1>
                        <div class="title-bar"></div>
                        <div class="home-abt-sub-title-dark">

                            <body style="background-color:teal">
                            <p>
                                <?php echo $about->description; ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="<?php echo e(asset('uploads/about/'.$about->image)); ?>" class="rounded" width="100%" height="336">
                    <div class="home-abt-text wow fadeInUp delay-0.4s ease animated">
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/pwsedu/praramva_code/resources/views/frontend/aboutUs.blade.php ENDPATH**/ ?>