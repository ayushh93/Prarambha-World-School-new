<?php $__env->startSection('main-content'); ?>
    <section id="homeEvents">
        <div class="container">
            <h2 class="section-title label">Management</h2>
            <div class="title-bar mx-auto"></div>
            <div class="owl-carousel owl-theme" id="eventSlider">
                <?php $__currentLoopData = $management; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item wow fadeInUp delay-0.5s ease animated">
                    <div class="image-wrap">
                        <a href="">
                            <img src="<?php echo e(asset('uploads/management/'.$mang->image)); ?>" />
                            <div class="event-overlay"></div>
                        </a>
                    </div>
                    <div class="event-bar">
                        <div class="event-block-date">
                            <div class="day"><?php echo e($mang->position); ?></div>

                        </div>
                        <div class="event-block-text">
                            <div class="event-block-title">
                                <?php echo e($mang->title); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- for space in managment  left-->

            <div class="home-events-links">


                </a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\prarambha\resources\views/frontend/management.blade.php ENDPATH**/ ?>