<?php $__env->startSection('main-content'); ?>
    <section id="homeAbout">
        <div class="container">
            <div class="row py-5">
                <div class="col-md-6">
                    <div class="home-abt-title wow fadeInLeft delay-0.5s ease animated">
                        <h1 class="large label">Kindergarten</h1>
                        <div class="title-bar"></div>
                        <div class="home-abt-sub-title-dark">

                            <body style="background-color:teal">
                            <p>
                                <?php echo $kinder->description; ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <a href="">
                        <img src="<?php echo e(asset('uploads/kinder/'.$kinder->image)); ?>" class="rounded" width="100%" height="300">
                        <div class="home-abt-text wow fadeInRight delay-0.4s ease animated">
                        </div>
                </div>
            </div>
        </div>

        <section id="portfolioPage" class="section-padd">
            <div class="container">
                <?php if($tabs): ?>
                <ul class="nav nav-tabs justify-content-center">
                    <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a <?php if($key == 0): ?> class="nav-link active" <?php else: ?> class="nav-link" <?php endif; ?> data-toggle="tab" href="#tab<?php echo e($key); ?>"><?php echo e($tab->title); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="tab-content">
                    <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="tab<?php echo e($key); ?>"  <?php if($key == 0): ?> class="tab-pane fade show active" <?php else: ?> class="tab-pane" <?php endif; ?> >
                              <div id="homeGallery inner-gallery" class="mx-auto">
                                    <div class="gallery-flex">
                                        <div class="row">
                                              <?php $__currentLoopData = $tabimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count=>$imag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <?php if($imag->tab_id == $tab->id): ?>
                                            <div class="col-lg-3 col-md-4">
                                                <div class="gallery-image">
                                                    <a href="<?php echo e(asset('uploads/tabimage/'.$imag->image)); ?>" data-fancybox="gallery">
                                                        <img src="<?php echo e(asset('uploads/tabimage/'.$imag->image)); ?>" alt="Image">
                                                    </a>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                            </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/prarambha/praramva_code/resources/views/frontend/kinder.blade.php ENDPATH**/ ?>